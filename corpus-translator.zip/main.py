def listToString(x):
 convertedList = ' '

 for ele in x:
    convertedList += ele
  
 return convertedList

direction = input("Translate to or from Corpus (to/from): ")

#English to Corpus translator
while direction == 'to':

 input_ = list(input("Input string: "))

 refTable = [ 'a' , 't' , 'y' , 'p' , 'e' ,'t' , 'j' , 'k' , 'i' , 't' , 'k' , 'p' , 's' , 't' , 'o' , 'k' , 'r' , 't' , 'y' , 'p' , 'u' , 't' , 'j' , 'k' , 'y' , 'b' , ' ' , ',' , '.' , "'" , '!' , '?']

 charCount = len(input_)

 test = 0

 while charCount > 0:
  if input_[test] == 'a':
   input_[test] = refTable[0]
   test += 1
   charCount -= 1
  elif input_[test] == 'b':
   input_[test] = refTable[1]
   test += 1
   charCount -= 1
  elif input_[test] == 'c':
   input_[test] = refTable[2]
   test += 1
   charCount -= 1
  elif input_[test] == 'd':
   input_[test] = refTable[3]
   test += 1
   charCount -= 1
  elif input_[test] == 'e':
   input_[test] = refTable[4]
   test += 1
   charCount -= 1
  elif input_[test] == 'f':
   input_[test] = refTable[5]
   test += 1
   charCount -= 1
  elif input_[test] == 'g':
   input_[test] = refTable[6]
   test += 1
   charCount -= 1
  elif input_[test] == 'h':
   input_[test] = refTable[7]
   test += 1
   charCount -= 1
  elif input_[test] == 'i':
   input_[test] = refTable[8]
   test += 1
   charCount -= 1
  elif input_[test] == 'j':
   input_[test] = refTable[9]
   test += 1
   charCount -= 1
  elif input_[test] == 'k':
   input_[test] = refTable[10]
   test += 1
   charCount -= 1
  elif input_[test] == 'l':
   input_[test] = refTable[11]
   test += 1
   charCount -= 1
  elif input_[test] == 'm':
   input_[test] = refTable[12]
   test += 1
   charCount -= 1
  elif input_[test] == 'n':
   input_[test] = refTable[13]
   test += 1
   charCount -= 1
  elif input_[test] == 'o':
   input_[test] = refTable[14]
   test += 1
   charCount -= 1
  elif input_[test] == 'p':
   input_[test] = refTable[15]
   test += 1
   charCount -= 1
  elif input_[test] == 'q':
   input_[test] = refTable[16]
   test += 1
   charCount -= 1
  elif input_[test] == 'r':
   input_[test] = refTable[17]
   test += 1
   charCount -= 1
  elif input_[test] == 's':
   input_[test] = refTable[18]
   test += 1
   charCount -= 1
  elif input_[test] == 't':
   input_[test] = refTable[19]
   test += 1
   charCount -= 1
  elif input_[test] == 'u':
   input_[test] = refTable[20]
   test += 1
   charCount -= 1
  elif input_[test] == 'v':
   input_[test] = refTable[21]
   test += 1
   charCount -= 1
  elif input_[test] == 'w':
   input_[test] = refTable[22]
   test += 1
   charCount -= 1
  elif input_[test] == 'x':
   input_[test] = refTable[23]
   test += 1
   charCount -= 1
  elif input_[test] == 'y':
   input_[test] = refTable[24]
   test += 1
   charCount -= 1
  elif input_[test] == 'z':
   input_[test] = refTable[25]
   test += 1
   charCount -= 1
  elif input_[test] == ' ':
   input_[test] = refTable[26]
   test += 1
   charCount -= 1
  elif input_[test] == ",":
   input_[test] = refTable[27]
   test += 1
   charCount -= 1
  elif input_[test] == ".":
   input_[test] = refTable[28]
   test += 1
   charCount -= 1
  elif input_[test] == "'":
   input_[test] = refTable[29]
   test += 1
   charCount -= 1
  elif input_[test] == "!":
   input_[test] = refTable[30]
   test += 1
   charCount -= 1
  elif input_[test] == "?":
   input_[test] = refTable[31]
   test += 1
   charCount -= 1

  output = listToString(input_)

 print(output)


#Corpus to English (Rough) translator
while direction == "from":

 input_ = list(input("Input string: "))

 refTable = ['a' , '(b/f/j/n/r/v)' , '(c/s/y)' , '(d/l/t)' , 'e' , '(g/w)' , '(h/k/p/x)' , 'i' , 'm' , 'o' , 'q' , 'u' , 'z' , ' ' , ',' , '.' , "'" , '!' , '?']

 charCount = len(input_)

 test = 0

 while charCount > 0:
  if input_[test] == 'a':
   input_[test] = refTable[0]
   test += 1
   charCount -= 1
  elif input_[test] == 't':
   input_[test] = refTable[1]
   test += 1
   charCount -= 1
  elif input_[test] == 'y':
   input_[test] = refTable[2]
   test += 1
   charCount -= 1
  elif input_[test] == 'p':
   input_[test] = refTable[3]
   test += 1
   charCount -= 1
  elif input_[test] == 'e':
   input_[test] = refTable[4]
   test += 1
   charCount -= 1
  elif input_[test] == 'j':
   input_[test] = refTable[5]
   test += 1
   charCount -= 1
  elif input_[test] == 'k':
   input_[test] = refTable[6]
   test += 1
   charCount -= 1
  elif input_[test] == 'i':
   input_[test] = refTable[7]
   test += 1
   charCount -= 1
  elif input_[test] == 's':
   input_[test] = refTable[8]
   test += 1
   charCount -= 1
  elif input_[test] == 'o':
   input_[test] = refTable[9]
   test += 1
   charCount -= 1
  elif input_[test] == 'r':
   input_[test] = refTable[10]
   test += 1
   charCount -= 1
  elif input_[test] == 'u':
   input_[test] = refTable[11]
   test += 1
   charCount -= 1
  elif input_[test] == 'b':
   input_[test] = refTable[12]
   test += 1
   charCount -= 1
  elif input_[test] == ' ':
   input_[test] = refTable[13]
   test += 1
   charCount -= 1
  elif input_[test] == ',':
   input_[test] = refTable[14]
   test += 1
   charCount -= 1
  elif input_[test] == '.':
   input_[test] = refTable[15]
   test += 1
   charCount -= 1
  elif input_[test] == "'":
   input_[test] = refTable[16]
   test += 1
   charCount -= 1
  elif input_[test] == '!':
   input_[test] = refTable[17]
   test += 1
   charCount -= 1
  elif input_[test] == '?':
   input_[test] = refTable[18]
   test += 1
   charCount -= 1


  output = listToString(input_)

 print(output)