import time
import random

def slowPrint(text):
  for x in text:
    print(x, end='', flush = True)
    time.sleep(0.01)
  print()

slowPrint("Welcome to my Python Pet")
slowPrint("There are currently three ways in which you can interact with the game. You can play with\n your pet, feed your pet, or check up your on pet. You will require money to buy food, which can be gained through working.")
slowPrint("Don't let your pet die of starvation or lack off attention! At any time type /help to get a list of the available commands.")

dieHunger = 'false'
dieMood = 'false'

score = 0

foodCount = 0

moneyBal = random.randint(25,60)

alive = 'true'

foodVal = random.randint(70,90)
moodVal = random.randint(70,90)


time.sleep(0.5)

while alive == 'true':
  
  foodVal -= random.randint(5,9)
  moodVal -= random.randint(3,7)

  if foodVal > 0:
    alive = 'true'
  elif foodVal <= 0:
    alive = 'false'
    dieHunger = 'true'

  if moodVal > 10:
    alive = 'true'
  elif moodVal <= 10:
    alive = 'false'
    dieMood = 'true'

  print("You have $",moneyBal, "dollars remaining")

  interact = input("What would you like to do? ")

  if interact == '/help':
    print("feed\nplay\ncheck\nwork\nbuyfood")
    interact = input("What would you like to do? ")

  if interact == 'feed':
    if foodVal >= 100:
      print("Your pet is full, you can't feed it anymore right now")
      foodVal = 99
    elif foodCount >= 1:
     print("You give your pet some kibble")
     foodVal += random.randint(10,18)
     foodCount -= 1
     score += 1
    elif foodCount <= 0:
      print("You have no food left")


  if interact == 'play':
    if moodVal >= 100:
      print("Your pet is as happy as can be")
      moodVal = 99
      score += 1
    else:
      print("You play with your pet a bit")
      moodVal += random.randint(10,18)
  
  if interact == 'work':
    print("You go to work for the day")
    moneyBal += random.randint(5,15)
    score += 1

  if interact == 'buyfood':
    print("You go to the store and buy two pet food")
    moneyBal -= 5
    foodCount += 2
    score += 1
  
  if interact == 'check':
    print("You check over your pet to make sure it is ok")
    if foodVal >= 70:
      print("I am full!")
    if 69 >= foodVal >= 31:
      print("I'm a little peckish.")
    if foodVal <= 30:
      print("Please feed me!")
    if moodVal >= 70:
      print("I'm enjoying myself!")
    if 69 >= moodVal >= 31:
      print("I'm getting a little bored.")
    if moodVal <= 30:
     print("Please play with me!")
    print("You have", foodCount, "pet food remaining")

if alive == 'false':
  if dieHunger == 'true':
    print("Your pet starved to death! Game Over!")
  if dieMood == 'true':
    print("Your pet ran away! Game Over!")

print("Your score was: " , score)

time.sleep(15)

quit
