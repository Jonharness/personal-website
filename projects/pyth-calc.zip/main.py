print("Hello, welcome to my fancy calculator")

import time

oploop = "invalid"

time.sleep(0.2)

#Check to see if an operator has been selected, if an invalid character is selected then it repeats the loop
while oploop == "invalid":
    operator = input("Please select an operation (+,-,*,/): ")
    if operator == "+":
        print("Operation selected - Addition")
        oploop = "valid"
    elif operator == "-":
        print("Operation selected - Subtraction")
        oploop = "valid"
    elif operator == "*":
        print("Operation selected - Multiplication")
        oploop = "valid"
    elif operator == "/":
        print("Operation selected - Division")
        oploop = "valid"
    else:
        print("Please select a valid Operation")
        oploop = "invalid"

     
#Gathering user inputs for numbers
number1 = float(input("Please select the first number: "))
number2 = float(input("Please select the second number: "))

time.sleep(1.3)

#Basic calculations using the operator and input numbers
if operator == "+":
    print("Result: ", number1 + number2)
elif operator == "-":
    print("Result: ", number1 - number2)
elif operator == "*":
    print("Result: ", number1 * number2)
elif operator == "/":
    print("Result: ", number1 / number2)

time.sleep(1.4)
print("Program Ending")