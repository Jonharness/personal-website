print("Welcome to a Nuclear Physics Calculator")

import time
#Sleep functions to make the program feel more natural#

#Array to reference weights of neutron, proton, electron
unitWeight = [1.008664, 1.007276, 0.00054858]
unit = ["u", "kg"]
#
#Get total weight of atom, number of protons
massNumber = int(input("Please input the Mass Number of the nucleus: "))
protonCount = int(input("Please input the Atomic Number of the nucleus: "))
#
#Calculate number of neutrons
neutronCount = (massNumber - protonCount)
#

#Display proton and neutron counts
print("The nucleus has:", protonCount, "protons",
      neutronCount, "neutrons")
#
#Calculate weights of protons and neutrons
protonWeight = float(protonCount * unitWeight[1])
neutronWeight = float(neutronCount * unitWeight[0])
#
#Display overall weight of 
print("Weighing:", protonWeight, unit[0], "(Protons)",
      neutronWeight, unit[0], "(Neutrons)")
#

#Query if the user would like to calculate an equation, return appropriate result
equationQuery = input("Would you like to calculate a Nuclear Equation? (Y/N): ")
if equationQuery == "Y":
    print("Initialising Nuclear Equation calculations")
elif equationQuery == "N":
    print("Thank you for using this Nuclear Physics Calculator, have a good day.")
    quit()
else:
    print("Invalid Input - Closing Program")
    quit()
#

#Get the first product nucleus figures
massNumber_1 = int(input("Please input the Mass Number of the first product Nucleus: "))
protonCount_1 = int(input("Please input the Atomic Number of the first product Nucleus: "))

neutronCount_1 = float(massNumber_1 - protonCount_1)
#
#as above
print("The nucleus has:", protonCount_1, "protons",
      neutronCount_1, "neutrons")

protonWeight_1 = float(protonCount_1 * unitWeight[1])
neutronWeight_1 = float(neutronCount_1 * unitWeight[0])

print("Weighing:", protonWeight_1, unit[0], "(Protons)",
      neutronWeight_1, unit[0], "(Neutrons)")
#
#Get the second product nucleus figures
massNumber_2 = int(input("Please input the Mass Number of the second product Nucleus: "))
protonCount_2 = int(input("Please input the Atomic Number of the second product Nucleus: "))

neutronCount_2 = float(massNumber_2 - protonCount_2)
#
#as above
print("The nucleus has:", protonCount_2, "protons",
      neutronCount_2, "neutrons")

protonWeight_2 = float(protonCount_2 * unitWeight[1])
neutronWeight_2 = float(neutronCount_2 * unitWeight[0])

print("Weighing:", protonWeight_2, "(Protons)",
      neutronWeight_2, "(Neutrons)")
#

#Calculate the total weight of the product atoms
productProtonCount = float(protonCount_1 + protonCount_2)
productNeutronCount = float(neutronCount_1 + neutronCount_2)

productProtonWeight = (productProtonCount * unitWeight[1])
productNeutronWeight = (productNeutronCount * unitWeight[0])

print("Total Product Weight:", productProtonWeight, "(Protons)",
      productNeutronWeight, "(Neutrons)")

#Determine how many neutrons were released in the equation
neutronRelease =int(input("How many neutrons were released in the reaction: "))

neutronReleaseMass = float(neutronRelease * unitWeight[0])

neutronWeightDifference = float(((neutronCount - productNeutronCount) * unitWeight[0]) - neutronReleaseMass)

print(neutronWeightDifference, unit[0])

#Convert the atomic units into KG to work with the mass energy equation
unitKG = 0.00000000000000000000000000166054
neutronWeightDiffKG = float(neutronWeightDifference * unitKG)

print(neutronWeightDiffKG, unit[1])

#energy = mass*speedoflight^2

energyProduce = float(neutronWeightDiffKG * (299792458*299792458))

print("Producing ", energyProduce, " joules of energy")